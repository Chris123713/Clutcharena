import React, { useMemo, useState } from "react";

type Match = {
  id: number;
  title: string;
  entry: number;
  prize: number;
  status: string;
  rules: string;
  host: string;
};

const initialMatches: Match[] = [
  {
    id: 1,
    title: "1v1 Aim Duel",
    entry: 500,
    prize: 900,
    status: "Open",
    rules: "First to 7 • No remakes unless both agree • Proof required",
    host: "AceRush",
  },
  {
    id: 2,
    title: "2v2 Swiftplay",
    entry: 750,
    prize: 1350,
    status: "Open",
    rules: "Best of 1 • Team captain reports result • Screenshot proof",
    host: "NovaClutch",
  },
  {
    id: 3,
    title: "1v1 Sheriff Only",
    entry: 250,
    prize: 450,
    status: "Filling",
    rules: "Sheriff only • First to 10 • No ability spam",
    host: "PixelVex",
  },
];

const recentResults = [
  { player: "AceRush", result: "Won 900 Points", mode: "1v1 Aim Duel" },
  { player: "PixelVex", result: "Won 450 Points", mode: "Sheriff Only" },
  { player: "NovaClutch", result: "Won 1,350 Points", mode: "2v2 Swiftplay" },
];

const colors = {
  bg: "#0a0a0b",
  panel: "#141417",
  panel2: "#1b1b20",
  border: "#2b2b34",
  text: "#f3f3f4",
  muted: "#a1a1aa",
  red: "#e11d48",
  softRed: "rgba(225, 29, 72, 0.12)",
  softBorder: "rgba(225, 29, 72, 0.25)",
};

const styles = {
  page: {
    minHeight: "100vh",
    background: colors.bg,
    color: colors.text,
    fontFamily: "Inter, Arial, sans-serif",
  } as React.CSSProperties,
  container: {
    maxWidth: 1200,
    margin: "0 auto",
    padding: "0 20px",
  } as React.CSSProperties,
  header: {
    position: "sticky",
    top: 0,
    zIndex: 50,
    borderBottom: `1px solid ${colors.border}`,
    background: "rgba(10,10,11,0.96)",
    backdropFilter: "blur(8px)",
  } as React.CSSProperties,
  rowBetween: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    flexWrap: "wrap",
  } as React.CSSProperties,
  brand: {
    fontSize: 28,
    fontWeight: 900,
    letterSpacing: -0.5,
  } as React.CSSProperties,
  subtitle: {
    color: colors.muted,
    fontSize: 12,
    marginTop: 4,
  } as React.CSSProperties,
  navWrap: {
    display: "flex",
    gap: 8,
    flexWrap: "wrap",
  } as React.CSSProperties,
  button: {
    padding: "10px 16px",
    borderRadius: 14,
    border: `1px solid ${colors.border}`,
    background: colors.panel2,
    color: colors.text,
    cursor: "pointer",
    fontWeight: 600,
  } as React.CSSProperties,
  buttonRed: {
    padding: "10px 16px",
    borderRadius: 14,
    border: `1px solid ${colors.red}`,
    background: colors.red,
    color: "white",
    cursor: "pointer",
    fontWeight: 700,
  } as React.CSSProperties,
  card: {
    background: colors.panel,
    border: `1px solid ${colors.border}`,
    borderRadius: 24,
    padding: 24,
  } as React.CSSProperties,
  cardSoft: {
    background: colors.panel2,
    border: `1px solid ${colors.border}`,
    borderRadius: 18,
    padding: 18,
  } as React.CSSProperties,
  heroGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
    gap: 24,
    alignItems: "center",
  } as React.CSSProperties,
  section: {
    padding: "40px 0",
  } as React.CSSProperties,
  titleXL: {
    fontSize: "clamp(40px, 7vw, 64px)",
    fontWeight: 900,
    lineHeight: 1.02,
    letterSpacing: -1.5,
    margin: 0,
  } as React.CSSProperties,
  titleL: {
    fontSize: 32,
    fontWeight: 800,
    margin: 0,
  } as React.CSSProperties,
  muted: {
    color: colors.muted,
    lineHeight: 1.7,
  } as React.CSSProperties,
  badge: {
    display: "inline-block",
    padding: "8px 12px",
    borderRadius: 999,
    background: colors.softRed,
    border: `1px solid ${colors.softBorder}`,
    color: "#fda4af",
    fontSize: 13,
    marginBottom: 16,
  } as React.CSSProperties,
  grid3: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
    gap: 16,
  } as React.CSSProperties,
  input: {
    width: "100%",
    padding: "14px 16px",
    borderRadius: 14,
    border: `1px solid ${colors.border}`,
    background: "#0f0f12",
    color: colors.text,
    outline: "none",
    boxSizing: "border-box" as const,
  },
  label: {
    display: "block",
    color: colors.muted,
    fontSize: 14,
    marginBottom: 8,
  } as React.CSSProperties,
  list: {
    display: "grid",
    gap: 14,
  } as React.CSSProperties,
  footer: {
    borderTop: `1px solid ${colors.border}`,
    color: colors.muted,
    padding: "28px 0 40px",
    marginTop: 30,
  } as React.CSSProperties,
};

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [page, setPage] = useState("home");
  const [username, setUsername] = useState("Wallis");
  const [loginInput, setLoginInput] = useState("");
  const [wallet, setWallet] = useState(2500);
  const [matches, setMatches] = useState<Match[]>(initialMatches);
  const [selectedMatch, setSelectedMatch] = useState<Match>(initialMatches[0]);
  const [myMatches, setMyMatches] = useState<Match[]>([]);
  const [createForm, setCreateForm] = useState({
    title: "1v1 Aim Duel",
    entry: 500,
    rules: "First to 7 • Proof required",
  });

  const stats = useMemo(() => {
    return {
      openMatches: matches.filter((m) => m.status !== "Settled").length,
      totalPrize: matches.reduce((sum, m) => sum + m.prize, 0),
      joined: myMatches.length,
    };
  }, [matches, myMatches]);

  const navButton = (label: string, key: string) => (
    <button
      onClick={() => setPage(key)}
      style={{
        ...styles.button,
        background: page === key ? colors.red : colors.panel2,
        borderColor: page === key ? colors.red : colors.border,
      }}
    >
      {label}
    </button>
  );

  const handleLogin = () => {
    const clean = loginInput.trim();
    setUsername(clean || "Wallis");
    setLoggedIn(true);
    setPage("dashboard");
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setPage("home");
  };

  const joinMatch = (match: Match) => {
    if (!loggedIn) {
      setPage("login");
      return;
    }
    if (wallet < match.entry) return;
    if (myMatches.find((m) => m.id === match.id)) return;

    setWallet((w) => w - match.entry);
    setMyMatches((prev) => [...prev, match]);
    setSelectedMatch(match);
    setPage("match");
  };

  const createMatch = () => {
    if (!loggedIn) {
      setPage("login");
      return;
    }

    const entry = Number(createForm.entry) || 0;
    if (entry <= 0 || wallet < entry) return;

    const newMatch: Match = {
      id: Date.now(),
      title: createForm.title,
      entry,
      prize: Math.floor(entry * 1.8),
      status: "Open",
      rules: createForm.rules,
      host: username,
    };

    setWallet((w) => w - entry);
    setMatches((prev) => [newMatch, ...prev]);
    setMyMatches((prev) => [newMatch, ...prev]);
    setSelectedMatch(newMatch);
    setPage("match");
  };

  const settleWin = () => {
    if (!selectedMatch) return;
    setWallet((w) => w + selectedMatch.prize);
    setMatches((prev) =>
      prev.map((m) =>
        m.id === selectedMatch.id ? { ...m, status: "Settled" } : m
      )
    );
    setSelectedMatch((prev) => ({ ...prev, status: "Settled" }));
  };

  return (
    <div style={styles.page}>
      <header style={styles.header}>
        <div style={{ ...styles.container, paddingTop: 18, paddingBottom: 18 }}>
          <div style={styles.rowBetween}>
            <div>
              <div style={styles.brand}>ClutchArena</div>
              <div style={styles.subtitle}>
                Interactive prototype for skill-match challenges
              </div>
            </div>

            <div style={styles.navWrap}>
              {navButton("Home", "home")}
              {navButton("Dashboard", "dashboard")}
              {navButton("Open Matches", "matches")}
              {navButton("Create Match", "create")}
              {navButton("Profile", "profile")}
            </div>

            <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
              <div style={{ ...styles.cardSoft, padding: "10px 14px", fontSize: 14 }}>
                Wallet: <strong>{wallet.toLocaleString()} pts</strong>
              </div>
              {loggedIn ? (
                <>
                  <div style={{ ...styles.cardSoft, padding: "10px 14px", fontSize: 14 }}>
                    @{username}
                  </div>
                  <button onClick={handleLogout} style={styles.button}>
                    Log Out
                  </button>
                </>
              ) : (
                <button onClick={() => setPage("login")} style={styles.buttonRed}>
                  Log In
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {page === "home" && (
        <section style={styles.section}>
          <div style={styles.container}>
            <div style={styles.heroGrid}>
              <div>
                <div style={styles.badge}>Live prototype • clickable • test flows</div>
                <h1 style={styles.titleXL}>
                  Test the platform
                  <span style={{ color: "#fb7185", display: "block" }}>before it is real.</span>
                </h1>
                <p style={{ ...styles.muted, fontSize: 18, maxWidth: 620 }}>
                  Click through login, browse matches, create new challenges, open a match page,
                  and test how the site feels with live front-end interactions.
                </p>

                <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 24 }}>
                  <button onClick={() => setPage("login")} style={styles.buttonRed}>
                    Test Login
                  </button>
                  <button onClick={() => setPage("matches")} style={styles.button}>
                    Browse Matches
                  </button>
                </div>

                <div style={{ ...styles.grid3, marginTop: 28 }}>
                  <div style={styles.cardSoft}>
                    <div style={{ fontSize: 30, fontWeight: 900 }}>{stats.openMatches}</div>
                    <div style={styles.muted}>Open Matches</div>
                  </div>
                  <div style={styles.cardSoft}>
                    <div style={{ fontSize: 30, fontWeight: 900 }}>{myMatches.length}</div>
                    <div style={styles.muted}>Your Entries</div>
                  </div>
                  <div style={{ ...styles.cardSoft }}>
                    <div style={{ fontSize: 30, fontWeight: 900 }}>{wallet}</div>
                    <div style={styles.muted}>Wallet Points</div>
                  </div>
                </div>
              </div>

              <div style={styles.card}>
                <div style={styles.rowBetween}>
                  <div>
                    <div style={{ fontSize: 22, fontWeight: 800 }}>Quick Demo Panel</div>
                    <div style={styles.subtitle}>Use these buttons to simulate the app</div>
                  </div>
                  <div style={{ ...styles.cardSoft, padding: "8px 12px", fontSize: 13 }}>
                    Stateful UI
                  </div>
                </div>

                <div style={{ ...styles.grid3, marginTop: 20 }}>
                  <button onClick={() => setPage("dashboard")} style={{ ...styles.cardSoft, cursor: "pointer", textAlign: "left" }}>
                    <div style={{ fontWeight: 700, marginBottom: 6 }}>Dashboard</div>
                    <div style={styles.muted}>See your wallet, entries, and stats.</div>
                  </button>
                  <button onClick={() => setPage("matches")} style={{ ...styles.cardSoft, cursor: "pointer", textAlign: "left" }}>
                    <div style={{ fontWeight: 700, marginBottom: 6 }}>Open Matches</div>
                    <div style={styles.muted}>Join listings and test entry flow.</div>
                  </button>
                  <button onClick={() => setPage("create")} style={{ ...styles.cardSoft, cursor: "pointer", textAlign: "left" }}>
                    <div style={{ fontWeight: 700, marginBottom: 6 }}>Create Match</div>
                    <div style={styles.muted}>Make a new match and add it to the list.</div>
                  </button>
                  <button
                    onClick={() => {
                      setSelectedMatch(matches[0]);
                      setPage("match");
                    }}
                    style={{ ...styles.cardSoft, cursor: "pointer", textAlign: "left" }}
                  >
                    <div style={{ fontWeight: 700, marginBottom: 6 }}>Match Page</div>
                    <div style={styles.muted}>Preview a full details layout.</div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {page === "login" && (
        <section style={styles.section}>
          <div style={{ ...styles.container, maxWidth: 600 }}>
            <div style={styles.card}>
              <h2 style={styles.titleL}>Log In Prototype</h2>
              <p style={styles.muted}>
                This is a front-end demo login so you can test the flow and see how the app would feel.
              </p>

              <div style={{ marginTop: 22 }}>
                <label style={styles.label}>Username</label>
                <input
                  value={loginInput}
                  onChange={(e) => setLoginInput(e.target.value)}
                  placeholder="Enter a username"
                  style={styles.input}
                />
              </div>

              <div style={{ marginTop: 16 }}>
                <label style={styles.label}>Password</label>
                <input type="password" placeholder="Demo only" style={styles.input} />
              </div>

              <button onClick={handleLogin} style={{ ...styles.buttonRed, width: "100%", marginTop: 22 }}>
                Enter Demo Account
              </button>
            </div>
          </div>
        </section>
      )}

      {page === "dashboard" && (
        <section style={styles.section}>
          <div style={styles.container}>
            <div style={styles.grid3}>
              <div style={styles.card}>
                <div style={styles.muted}>Wallet</div>
                <div style={{ fontSize: 42, fontWeight: 900, marginTop: 8 }}>{wallet.toLocaleString()}</div>
                <div style={{ ...styles.muted, marginTop: 8 }}>Platform points available</div>
              </div>
              <div style={styles.card}>
                <div style={styles.muted}>Joined Matches</div>
                <div style={{ fontSize: 42, fontWeight: 900, marginTop: 8 }}>{stats.joined}</div>
                <div style={{ ...styles.muted, marginTop: 8 }}>Entries linked to your account</div>
              </div>
              <div style={styles.card}>
                <div style={styles.muted}>Total Open Prize</div>
                <div style={{ fontSize: 42, fontWeight: 900, marginTop: 8 }}>{stats.totalPrize.toLocaleString()}</div>
                <div style={{ ...styles.muted, marginTop: 8 }}>Visible across public matches</div>
              </div>
            </div>

            <div style={{ ...styles.heroGrid, marginTop: 24 }}>
              <div style={styles.card}>
                <h2 style={{ ...styles.titleL, marginBottom: 18 }}>Your Active Matches</h2>
                <div style={styles.list}>
                  {myMatches.length === 0 ? (
                    <div style={styles.cardSoft}>No matches joined yet. Try joining one from Open Matches.</div>
                  ) : (
                    myMatches.map((match) => (
                      <button
                        key={match.id}
                        onClick={() => {
                          setSelectedMatch(match);
                          setPage("match");
                        }}
                        style={{ ...styles.cardSoft, textAlign: "left", cursor: "pointer" }}
                      >
                        <div style={{ fontWeight: 700, fontSize: 18 }}>{match.title}</div>
                        <div style={{ ...styles.muted, marginTop: 6 }}>
                          Entry: {match.entry} • Prize: {match.prize}
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </div>

              <div style={styles.card}>
                <h2 style={{ ...styles.titleL, marginBottom: 18 }}>Recent Results</h2>
                <div style={styles.list}>
                  {recentResults.map((item, index) => (
                    <div key={index} style={styles.cardSoft}>
                      <div style={{ fontWeight: 700 }}>{item.player}</div>
                      <div style={{ ...styles.muted, marginTop: 6 }}>{item.mode}</div>
                      <div style={{ color: "#fb7185", marginTop: 10, fontSize: 14 }}>{item.result}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {page === "matches" && (
        <section style={styles.section}>
          <div style={styles.container}>
            <div style={{ ...styles.rowBetween, marginBottom: 18 }}>
              <div>
                <h2 style={styles.titleL}>Open Matches</h2>
                <p style={styles.muted}>Join a listing to test the platform flow.</p>
              </div>
              <button onClick={() => setPage("create")} style={styles.buttonRed}>
                Create Your Own
              </button>
            </div>

            <div style={styles.list}>
              {matches.map((match) => (
                <div key={match.id} style={styles.card}>
                  <div style={styles.rowBetween}>
                    <div>
                      <div style={{ fontSize: 24, fontWeight: 800 }}>{match.title}</div>
                      <div style={{ ...styles.muted, marginTop: 6 }}>Hosted by @{match.host}</div>
                      <div style={{ ...styles.muted, marginTop: 10 }}>
                        Entry: {match.entry} pts • Prize: {match.prize} pts • Status: {match.status}
                      </div>
                      <div style={{ color: "#8b8b95", marginTop: 10 }}>{match.rules}</div>
                    </div>

                    <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                      <button
                        onClick={() => {
                          setSelectedMatch(match);
                          setPage("match");
                        }}
                        style={styles.button}
                      >
                        View
                      </button>
                      <button onClick={() => joinMatch(match)} style={styles.buttonRed}>
                        Join Match
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {page === "create" && (
        <section style={styles.section}>
          <div style={{ ...styles.container, maxWidth: 800 }}>
            <div style={styles.card}>
              <h2 style={styles.titleL}>Create a Match</h2>
              <p style={styles.muted}>
                Change the values and publish a new listing.
              </p>

              <div style={{ marginTop: 22 }}>
                <label style={styles.label}>Match Title</label>
                <input
                  value={createForm.title}
                  onChange={(e) => setCreateForm((f) => ({ ...f, title: e.target.value }))}
                  style={styles.input}
                />
              </div>

              <div style={{ marginTop: 16 }}>
                <label style={styles.label}>Entry Points</label>
                <input
                  type="number"
                  value={createForm.entry}
                  onChange={(e) =>
                    setCreateForm((f) => ({ ...f, entry: Number(e.target.value) || 0 }))
                  }
                  style={styles.input}
                />
              </div>

              <div style={{ marginTop: 16 }}>
                <label style={styles.label}>Rules</label>
                <textarea
                  value={createForm.rules}
                  onChange={(e) => setCreateForm((f) => ({ ...f, rules: e.target.value }))}
                  rows={4}
                  style={{ ...styles.input, resize: "vertical" as const }}
                />
              </div>

              <div style={{ ...styles.cardSoft, marginTop: 18 }}>
                Estimated prize:{" "}
                <strong style={{ color: "#fb7185" }}>
                  {Math.floor((Number(createForm.entry) || 0) * 1.8)} pts
                </strong>
              </div>

              <button onClick={createMatch} style={{ ...styles.buttonRed, width: "100%", marginTop: 18 }}>
                Publish Challenge
              </button>
            </div>
          </div>
        </section>
      )}

      {page === "match" && selectedMatch && (
        <section style={styles.section}>
          <div style={styles.container}>
            <div style={styles.heroGrid}>
              <div style={styles.card}>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 16 }}>
                  <div style={styles.badge}>{selectedMatch.status}</div>
                  <div style={{ ...styles.cardSoft, padding: "8px 12px", fontSize: 13 }}>
                    Hosted by @{selectedMatch.host}
                  </div>
                </div>

                <h2 style={{ ...styles.titleL, fontSize: 42 }}>{selectedMatch.title}</h2>
                <p style={{ ...styles.muted, marginTop: 12 }}>{selectedMatch.rules}</p>

                <div style={{ ...styles.grid3, marginTop: 24 }}>
                  <div style={styles.cardSoft}>
                    <div style={styles.muted}>Entry</div>
                    <div style={{ fontSize: 34, fontWeight: 900, marginTop: 8 }}>{selectedMatch.entry} pts</div>
                  </div>
                  <div style={styles.cardSoft}>
                    <div style={styles.muted}>Prize</div>
                    <div style={{ fontSize: 34, fontWeight: 900, marginTop: 8 }}>{selectedMatch.prize} pts</div>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 24 }}>
                  <button onClick={() => joinMatch(selectedMatch)} style={styles.buttonRed}>
                    Join This Match
                  </button>
                  <button onClick={settleWin} style={styles.button}>
                    Simulate Win Payout
                  </button>
                </div>
              </div>

              <div style={{ display: "grid", gap: 18 }}>
                <div style={styles.card}>
                  <div style={{ fontSize: 22, fontWeight: 800 }}>Proof & Disputes</div>
                  <p style={{ ...styles.muted, marginTop: 10 }}>
                    Later we can add clickable proof uploads, result confirmation, and admin review states.
                  </p>
                </div>

                <div style={styles.card}>
                  <div style={{ fontSize: 22, fontWeight: 800 }}>Prototype Notes</div>
                  <div style={{ ...styles.muted, marginTop: 10 }}>
                    • Login is demo-only
                    <br />
                    • Wallet updates live in preview
                    <br />
                    • Creating and joining matches changes state live
                    <br />
                    • No backend connected yet
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {page === "profile" && (
        <section style={styles.section}>
          <div style={styles.container}>
            <div style={styles.heroGrid}>
              <div style={styles.card}>
                <div style={{ ...styles.subtitle, textTransform: "uppercase", letterSpacing: 2 }}>
                  Profile
                </div>
                <div style={{ fontSize: 36, fontWeight: 900, marginTop: 10 }}>@{username}</div>
                <div style={{ ...styles.muted, marginTop: 6 }}>Competitive player profile preview</div>

                <div style={{ ...styles.cardSoft, marginTop: 18 }}>
                  <div style={styles.muted}>Wallet Balance</div>
                  <div style={{ fontSize: 28, fontWeight: 900, marginTop: 6 }}>{wallet} pts</div>
                </div>
              </div>

              <div style={styles.card}>
                <div style={{ fontSize: 28, fontWeight: 800, marginBottom: 18 }}>Activity</div>
                <div style={styles.list}>
                  {myMatches.length === 0 ? (
                    <div style={styles.cardSoft}>No profile activity yet. Join or create a match to generate activity here.</div>
                  ) : (
                    myMatches.map((match) => (
                      <div key={match.id} style={styles.cardSoft}>
                        <div style={{ fontWeight: 700 }}>{match.title}</div>
                        <div style={{ ...styles.muted, marginTop: 6 }}>
                          Entry: {match.entry} pts • Prize: {match.prize} pts
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      <footer style={styles.footer}>
        <div style={styles.container}>
          © 2026 ClutchArena interactive prototype. This preview supports clickable testing,
          but it is not connected to a real backend yet.
        </div>
      </footer>
    </div>
  );
}
